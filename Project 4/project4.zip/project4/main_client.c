/**
 * Shwetha Raju & Riya Patel
 * Project 4: Network Programming
 * main_client.c file
 * CSC 345 - 01 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h> 
#include <pthread.h>

#define PORT_NUM 1004
#define ROOM_MAX 5

void error(const char *msg){
	perror(msg);
	exit(0);
}

typedef struct _ThreadArgs {
	int clisockfd;
} ThreadArgs;

void* thread_main_recv(void* args)
{
	int sockfd = ((ThreadArgs*) args)->clisockfd;
	free(args);

	char buffer[512];
	int n = recv(sockfd, buffer, 512, 0);
	printf("\n%s\n", buffer);
	while (n > 0) { 
		memset(buffer, 0, 512);
		n = recv(sockfd, buffer, 512, 0);
		printf("\n%s\n", buffer);
	}
	return NULL;
}

void* thread_main_send(void* args)
{
	int sockfd = ((ThreadArgs*) args)->clisockfd;
	free(args);

	/* keep sending messages to the server */
	char buffer[256];
	int n;
	int haveUsername = 0;

	while (1) {
		if (haveUsername == 0 ) 
			printf("\nEnter a username: ");
		else printf("\nEnter a message: ");

		memset(buffer, 0, 256);
		fgets(buffer, 255, stdin);
		if (strlen(buffer) == 1) 
			buffer[0] = '\0';
		if (buffer[strlen(buffer)-1] == 10) 
			buffer[strlen(buffer)-1] = '\0'; /* remove newline */
		if (!haveUsername && strlen(buffer) > 12) 
			continue; /* check that username will fit in buffer */
		else 
			haveUsername = 1;
		n = send(sockfd, buffer, strlen(buffer), 0);
		if (n < 0) 
			error("ERROR writing to socket");
		if (n == 0) 
			break; 
	}
	return NULL;
}

int main(int argc, char *argv[]){
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in serv_addr;
	socklen_t slen = sizeof(serv_addr);
	memset((char*) &serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = inet_addr(argv[1]);
	serv_addr.sin_port = htons(PORT_NUM);

	printf("Trying to connect to %s...\n", inet_ntoa(serv_addr.sin_addr));

	int status = connect(sockfd, (struct sockaddr *) &serv_addr, slen);
	int isNum = 1;
	char buffer[256];
	memset(buffer, 0, 256);
	if (argc > 2) 
		strcpy(buffer, argv[2]);
	else {
		buffer[0] = 10;
		isNum = 0;
	}
	for (int i=0;i<strlen(buffer)-1;i++){
		if (buffer[i] < 48 || buffer[i] > 57){  /* chars 0 to 9 are 48 to 57 */
			isNum = 0;
			break;
		}
	}
	status = send(sockfd, buffer, strlen(buffer), 0); /* send room number to server */

	if (isNum){ /* validate room number */
		memset(buffer, 0, 256);
		int nrcv = recv(sockfd, buffer, 255, 0);
		printf("\n%s", buffer);
	}

	if (strcmp(buffer,"new") == 0){
		memset(buffer, 0, 256);
		int nrcv = recv(sockfd, buffer, 255, 0);
		printf("\n%s\n", buffer);
	} else if (argc < 3){ /* no new room request */
		char maxBuffer[4096];
		memset(maxBuffer, 0, 4096);
		int nrcv = recv(sockfd, maxBuffer, 4096, 0);
		printf("\n%s\n", maxBuffer);
		char word[9]; /* "connected" string */
		strncpy(word, maxBuffer, 9);
		if (strcmp(word,"Connected") != 0){
			int numRooms = 0;
			for (int i=0;i<strlen(maxBuffer)-1;i++){
				numRooms += (maxBuffer[i] == 9); /* check for TAB characters */
			}
			while (1){
				memset(buffer, 0, 256);
				fgets(buffer, 255, stdin);

				int isNum = 1;
				for (int i=0;i<strlen(buffer)-1;i++){
					if (buffer[i] < 48 || buffer[i] > 57){ // chars 0 to 9 are 48 to 57
						isNum = 0;
						break;
					}
				}
				if ((isNum && atoi(buffer) <= numRooms)|| strcmp(buffer,"new\n") == 0) 
					break;
				else 
					printf("\nChoose a room number or type [new] to create a new room: ");
			}
			if (buffer[strlen(buffer)-1] == 10) 
				buffer[strlen(buffer)-1] = '\0';
			int n = send(sockfd, buffer, strlen(buffer), 0);
		}
	}

	pthread_t tid1;
	pthread_t tid2;
	ThreadArgs* args;
	int errno = 0;
	args = (ThreadArgs*) malloc(sizeof(ThreadArgs));
	args->clisockfd = sockfd;
	errno = pthread_create(&tid1, NULL, thread_main_send, (void*) args);
	args = (ThreadArgs*) malloc(sizeof(ThreadArgs));
	args->clisockfd = sockfd;
	errno = pthread_create(&tid2, NULL, thread_main_recv, (void*) args);

	pthread_join(tid1, NULL);

	close(sockfd);
	printf("\nFile descriptor closed connection\n");
	return 0;
}