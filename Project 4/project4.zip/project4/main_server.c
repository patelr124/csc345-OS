/**
 * Shwetha Raju & Riya Patel
 * Project 4: Network Programming
 * main_server.c file
 * CSC 345 - 01 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>

/* define const variables */
#define PORT_NUM 1004
#define ROOM_MAX 5

int roomNUM[ROOM_MAX+1] = {0}; 	// array to keep track of the number of people in rooms 
int roomsOPEN = 0; 				// number of rooms that are currently open

void error(const char *msg){
	perror(msg);
	exit(1);
}

/* declaring user structure */
typedef struct _USR {
	int clisockfd;				// socket file descriptor
	struct _USR* next;			// for linked list queue
    char clientname[12];		// client name
    int room;           		// room number where client is in
    int color;
} USR;

USR *head = NULL;				// traversal 
USR *tail = NULL;				// new clients added 

/* method prints out the list of current clients active */
void clientList();
void clientList(){
	USR* current = head;
	if(head != NULL){
				current = head;
		printf("Connected Clients List: \n");
		while (current != NULL){
			printf("Client Name: %s - Room Number: %d \n", current->clientname, current ->room);
			current = current->next;	
		}
	} else{
		printf("No Connected Clients. \n");
	}	
}

/* method to select randomized color for clients */
int colorSelection();
int colorSelection() {
	int index = rand() % 6;
	return index + 91;
}


/* return room number/create a new room based on client input */
int getRoomNum(int clisockfd, struct sockaddr_in cli_addr, char* room){
	
	int isInt = 1;
	int isEmpty = 0;
	int curNum;

	/* checks that input has chars 0-9 -> 48 to 57 */
	for (int i=0;i < strlen(room)-1; i++) {
		if (room[i] < 48 || room[i] > 57) {
			isInt = 0;
			break;
		}
	}
	if (room[0] == 10){ /* check for no input */
		isInt = 0;
		isEmpty = 1;
	}

	if (isInt){ /* input is integer, checks to see if it's available */
		curNum = atoi(room);
		if (0 < curNum && curNum <= ROOM_MAX && curNum <= roomsOPEN) { /* room num valid checker */
			memset(room,0,256);
			sprintf(room,"Success, you have entered the chat room. \n");
			int nmsg = strlen(room);
			int nsen = send(clisockfd, room, nmsg, 0);
			return curNum;
		}
		else{ /* invalid input */
			memset(room,0,256);
			sprintf(room,"ERROR. Room Unavailable. \n");
			int nmsg = strlen(room);
			int nsen = send(clisockfd, room, nmsg, 0);
			return 0;
		}
	}
	else { /* input is string (if 'new' -> increment current curNum */
		int isNew = strcmp(room,"new");

		if ((isNew == 0 && roomsOPEN < ROOM_MAX) || (isEmpty == 1 && roomsOPEN == 0)){
			roomsOPEN += 1;
			curNum = roomsOPEN;

			char buffer[256];
			memset(buffer, 0, 256);
			sprintf(buffer, "Connected to IP Address: %s Room: %d\n Hit 'Enter' to Continue.", inet_ntoa(cli_addr.sin_addr), curNum);

			int nmsg = strlen(buffer);
			int nsen = send(clisockfd, buffer, nmsg, 0);

			memset(buffer, 0, 256);
			return curNum;
		}
		else if ((isEmpty == 1 && roomsOPEN != 0 && roomsOPEN < ROOM_MAX) || room[0] == 11) {

			char buffer[4096];
			memset(buffer, 0, 4096);
			sprintf(buffer, "Available Rooms: \n");

			for (int i = 0; i < roomsOPEN; i++){
				char room[32];
				int numPeople = roomNUM[i];
				if (numPeople > 1 || numPeople == 0) sprintf(room, "\tRoom %d: %d people\n", i+1, numPeople);
				else sprintf(room, "\tRoom %d: %d person\n", i+1, numPeople);

				if (strlen(buffer) + strlen(room) < 4096){
					strcat(buffer, room);
				} 
			}

			strcat(buffer, "Enter Room Number. Enter 'new' for New Room.");
			int nmsg = strlen(buffer);
			int nsen = send(clisockfd, buffer, nmsg, 0);

			char newbuf[256];
			memset(newbuf, 0, 256);
			int nrcv = recv(clisockfd, newbuf, 255, 0);

			/* calling getRoomNum function recursively using a new call */
			return getRoomNum(clisockfd, cli_addr, newbuf);
		}
	}
	return 0;
}

/* adds clients to the tail of linked list */
void addTail(int newclisockfd, char* clientname, int room_num){
	if (head != NULL) {
		/* malloc used when variable is not an INT */
		tail->next = (USR*) malloc(sizeof(USR));
		tail = tail->next;
		tail->clisockfd = newclisockfd;

		strcpy(tail->clientname, clientname);
		
		tail->color = colorSelection();
		tail->room = room_num;
		
		tail->next = NULL;
	} 
	else {
		/* malloc used when variable is not an INT */
		head = (USR*) malloc(sizeof(USR));
		head->clisockfd = newclisockfd;

		strcpy(head->clientname, clientname);
	
		head->color = colorSelection();
		head->room = room_num;

		head->next = NULL;
		tail = head;
	}
}

/* sending messages between clients */
void broadcast(int fromfd, char* message) {

	/* figure out sender address */
	struct sockaddr_in cliaddr;
	socklen_t clen = sizeof(cliaddr);

	char buddyName[12];
	int buddyRoom, buddyColor;
	USR* current = head; /* traverse through all connected clients */

	/* finding client who sent message */
	while (current != NULL) {
		/* check to see if current sent the message */
		if(fromfd == current->clisockfd) {
			strcpy(buddyName, current->clientname);
			buddyRoom = current->room;
			buddyColor = current->color;
			break;
		}
		current = current->next;
	}
	current = head;

	/* iterating through all clients online */
	while (current != NULL) {
		/* if current client is NOT client that sent message */
		if (current->room == buddyRoom && current->clisockfd != fromfd) {
			char buffer[512];
			memset(buffer, 0, 512);

			/* preparing message to send */
			sprintf(buffer, "\x1B[%dm[%s (%s)]: %s\x1B[0m", buddyColor, buddyName, inet_ntoa(cliaddr.sin_addr), message);
			int nmsg = strlen(buffer);

			/* sending message */
			int nsen = send(current->clisockfd, buffer, nmsg, 0);
		}
		current = current->next;
	}
}

void announce(int fromfd, int mode) {

	/* figure out sender address */
	struct sockaddr_in cliaddr;
	socklen_t clen = sizeof(cliaddr);

	char buddyName[12];
	int buddyRoom, buddyColor;
	USR* current = head; /* traverse through all connected clients */

	/* finding client who sent message */
	while (current != NULL) {
		/* check to see if current sent the message */
		if(fromfd == current->clisockfd) {
			strcpy(buddyName, current->clientname);
			buddyRoom = current->room;
			buddyColor = current->color;
			break;
		}
		current = current->next;
	}
	current = head;

	/* iterating through all clients online */
	while (current != NULL) {
		/* if current client is NOT client that sent message */
		if (current->room == buddyRoom && current->clisockfd != fromfd) {
			char buffer[512];
			memset(buffer, 0, 512);

			/* preparing message to send */
			if (mode == 0){
				sprintf(buffer, "%s has left the chat.", buddyName);
			} else sprintf(buffer, "%s has entered the chat.", buddyName);
			int nmsg = strlen(buffer);

			/* sending message */
			int nsen = send(current->clisockfd, buffer, nmsg, 0);
		}
		current = current->next;
	}
	if(mode == 0) current = head;
}

/* ThreadArgs - Holds client socket file descriptor */
typedef struct _ThreadArgs {
	int clisockfd;
} ThreadArgs;

/* worker function for indivisual threads */
void* thread_main(void* args){
	/* make sure thread resources are deallocated upon return */
	pthread_detach(pthread_self());
    /* get socket descriptor from argument */
	int clisockfd = ((ThreadArgs*) args)->clisockfd;
	free(args);

    /* Now, we receive/send messages */
	char buffer[256];
	memset(buffer, 0, 256);
	int nsen, nrcv;

	USR* current = head;
	USR* previous = NULL;

	memset(buffer, 0, 256);
	nrcv = recv(clisockfd, buffer, 255, 0);

	/* sending message to everyone in chatroom but sender */
	while (nrcv > 0) {
		broadcast(clisockfd, buffer);
		memset(buffer, 0, 256);
		nrcv = recv(clisockfd, buffer, 255, 0);
		if (nrcv == 0){ /* client disconnects */
			while (current != NULL){
				if(current->clisockfd == clisockfd){
					printf("Disconnected Client: (%s)\n", current->clientname);
					announce(clisockfd,0);
					roomNUM[(current->room)- 1]--;
					if(previous == NULL){
						head = current->next;
						free(current);
					} else {
						previous->next = current->next;
						free(current);
					}
					break;
				}
				previous = current;
				current = current->next;
			}
		}
		clientList();
	}
	close(clisockfd);
	return NULL;
}

int main(int argc, char *argv[]) {
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0){
		error("ERROR opening socket");
	}

	struct sockaddr_in serv_addr;
	socklen_t slen = sizeof(serv_addr);
	memset((char*) &serv_addr, 0, sizeof(serv_addr));

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;		
	serv_addr.sin_port = htons(PORT_NUM);

	int status = bind(sockfd, (struct sockaddr*) &serv_addr, slen);
	if (status < 0){
		error("ERROR on binding");
	} 
	listen(sockfd, 5);

	while(1) {
		struct sockaddr_in cli_addr;
		socklen_t clen = sizeof(cli_addr);
		int newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clen);
	
		char room[256];
		memset(room, 0, 256);
		/* get room number from client input */
		int nrcv = recv(newsockfd, room, 255, 0);
		
		/* calling method that will get/create room */
		int roomNum = getRoomNum(newsockfd, cli_addr, room);
		if (roomNum == 0){ /* condition when roomNum fails*/
			printf("Could not create or find room\n");
			continue;
		}

		roomNUM[roomNum-1] += 1;				/* update room count */
        char clientname[256];      				/* storing client name */

		memset(clientname, 0, 256);
		nrcv = recv(newsockfd, clientname, 255, 0);
	
		printf("Connected: %s (%s)\n", inet_ntoa(cli_addr.sin_addr), clientname);
		/* adds new client to list */
		addTail(newsockfd, clientname, roomNum);
		announce(newsockfd, 1);
		/*preparing ThreadArgs structure */
		ThreadArgs* args = (ThreadArgs*) malloc(sizeof(ThreadArgs));
		if (args == NULL){
			error("ERROR creating thread argument");
		}
		args->clisockfd = newsockfd;
		pthread_t tid;
		if (pthread_create(&tid, NULL, thread_main, (void*) args) != 0) error("ERROR creating a new thread");
		else clientList();
	}

	close(sockfd);
	return 0; 
}